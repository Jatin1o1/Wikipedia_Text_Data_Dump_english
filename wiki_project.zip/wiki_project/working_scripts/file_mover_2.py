import os
import shutil

directory= 'C:\wiki_project\working_scripts' 
    
count=0
for file in os.listdir(directory):
    if not os.path.exists('C:\\wiki_project\\sorted\\'+ str(file[0])):
        os.makedirs('C:\\wiki_project\\sorted\\'+ str(file[0]))
    


    current_file= directory+ '\\' + str(file)

    
    if file.endswith('.txt'):

        if file[0] not in [' ']:
            dest= 'C:\\wiki_project\\sorted\\'+ str(file[0]) + '\\' + str(file)
            shutil.move(current_file, dest)
            count += 1
            print("moved " + str(count) + '  '+file )
        
        
        #if file[0] not in [' ', '!', '$','%','&','*','@',"'",'(',')','-','_','+','=',',','.','?','/','`','~','á'] :
            #dest= 'C:\\wiki_project\\sorted\\'+ str(file[0]) + '\\' + str(file)
            #shutil.move(current_file, dest)
            #print("moved " + file )
        



