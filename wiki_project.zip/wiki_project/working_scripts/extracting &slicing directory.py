'''
This script is used after processing wikipedia data dump with "wikiextractor" (github repo),
this script read the files from extracted directory and extract articles and saves them into new file.

'''

''' readline() is a function that has buffer attached to it, it keeps track of the last line it has read and upon calling it reads the next line.'''

# this script read a  file and extract a portion of it and saves it into a new file.

import os
import sys
sys.setrecursionlimit(10**6)     # setting recursion limit to 1 million

x=['EI']     # directory names 

for i in x:
    directory= 'C:\\wiki project\\fds\\' + str(i)
    

    #directory= 'C:\\wiki project\\fds\\EG'   # directory where files are located

    enteries= os.listdir(directory)          #making list of file in directory

    for entry in enteries:               # looping through diretory files
        
        file_name= directory+ '\\' + str(entry)
        print("working with :  " + file_name)       # printing current file in use
        
        inFile = open(file_name, errors='ignore')
        def Jatin():
            line = inFile.readline()

            if line.startswith("<doc id"):      #removing symbols from filename to avoid error
                topic_name = inFile.readline().strip()
                if "/" in topic_name:
                    topic_name=topic_name.replace("/",",")
                if "?" in topic_name:
                    topic_name=topic_name.replace("?"," ")
                if ":" in topic_name:
                    topic_name=topic_name.replace(":","-")
                if "*" in topic_name:
                    topic_name=topic_name.replace("*","-")                

                #print("topic name is : " + topic_name)
                   
                newfile_name=topic_name + ".txt"    
                doc= open(newfile_name, "w")         # making a new file and opening it 
               
                while True:
                    cline=inFile.readline()          # looping to read  a new line

                    if cline.startswith("</doc>"):
                        doc.close()
                        #print("breaking")
                        Jatin()                 # calling recursive function 
                        break
                    else:
                        #print(cline)
                        doc.write(cline)
                        
     
        #print("new line is "+ inFile.readline())
        Jatin()    
        inFile.close()
