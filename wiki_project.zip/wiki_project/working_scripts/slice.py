inFile = open("/home/jatin/Music/wiki project/AA/wiki_00.txt")
line = inFile.readline()
if line.startswith("<doc id"):
    topic_name = inFile.readline()
    print("topic name is : " + topic_name)
    while True:
        cline=inFile.readline()
        if cline.startswith("</doc>"):
            break
        else:
            print(cline)
    print("breaking")
    #print("new line is "+ inFile.readline())
    inFile.close()
