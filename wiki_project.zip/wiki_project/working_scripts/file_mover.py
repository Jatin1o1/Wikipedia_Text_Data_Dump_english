import os
import shutil

directory= 'C:\\wiki_project\\processed_data\\data' 
    

for file in os.listdir(directory):



    current_file= directory+ '\\' + str(file)

    dest= 'C:\\wiki_project\\sorted\\ ' + str(file)

    if file.startswith("A"):
        dest= 'C:\\wiki_project\\sorted\\A\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("B"):
        dest= 'C:\\wiki_project\\sorted\\B\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("D"):
        dest= 'C:\\wiki_project\\sorted\\C\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("D"):
        dest= 'C:\\wiki_project\\sorted\\D\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("E"):
        dest= 'C:\\wiki_project\\sorted\\E\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("F"):
        dest= 'C:\\wiki_project\\sorted\\F\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("G"):
        dest= 'C:\\wiki_project\\sorted\\G\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("H"):
        dest= 'C:\\wiki_project\\sorted\\H\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("I"):
        dest= 'C:\\wiki_project\\sorted\\I\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("J"):
        dest= 'C:\\wiki_project\\sorted\\J\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("K"):
        dest= 'C:\\wiki_project\\sorted\\K\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("L"):
        dest= 'C:\\wiki_project\\sorted\\L\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("M"):
        dest= 'C:\\wiki_project\\sorted\\M\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("N"):
        dest= 'C:\\wiki_project\\sorted\\N\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("O"):
        dest= 'C:\\wiki_project\\sorted\\O\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("P"):
        dest= 'C:\\wiki_project\\sorted\\P\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("Q"):
        dest= 'C:\\wiki_project\\sorted\\Q\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("R"):
        dest= 'C:\\wiki_project\\sorted\\R\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("S"):
        dest= 'C:\\wiki_project\\sorted\\S\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("T"):
        dest= 'C:\\wiki_project\\sorted\\T\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("U"):
        dest= 'C:\\wiki_project\\sorted\\U\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("V"):
        dest= 'C:\\wiki_project\\sorted\\V\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("W"):
        dest= 'C:\\wiki_project\\sorted\\W\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("X"):
        dest= 'C:\\wiki_project\\sorted\\X\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("Y"):
        dest= 'C:\\wiki_project\\sorted\\Y\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("Z"):
        dest= 'C:\\wiki_project\\sorted\\Z\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("0"):
        dest= 'C:\\wiki_project\\sorted\\0\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

 #   if file.startswith("1"):
  #      dest= 'C:\\wiki_project\\sorted\\1\\ ' + str(file)
   #     shutil.move(current_file, dest)
    #    print("moved " + file)

    if file.startswith("2"):
        dest= 'C:\\wiki_project\\sorted\\2\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("3"):
        dest= 'C:\\wiki_project\\sorted\\3\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("4"):
        dest= 'C:\\wiki_project\\sorted\\4\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("5"):
        
        dest= 'C:\\wiki_project\\sorted\\5\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("6"):
        dest= 'C:\\wiki_project\\sorted\\6\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("7"):
        dest= 'C:\\wiki_project\\sorted\\7\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("8"):
        dest= 'C:\\wiki_project\\sorted\\8\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)

    if file.startswith("9"):
        dest= 'C:\\wiki_project\\sorted\\9\\ ' + str(file)
        shutil.move(current_file, dest)
        print("moved " + file)
