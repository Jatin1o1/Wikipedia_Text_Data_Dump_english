''' readline() is a function that has buffer attached to it, it keeps track of the last line it has read and upon calling it reads the next line.'''

# this script read a  file and extract a portion of it and saves it into a new file.


inFile = open("C:\wiki project\AA\wiki_00.txt")
line = inFile.readline()
if line.startswith("<doc id"):
    
    topic_name = inFile.readline().strip()
    #print("topic name is : " + topic_name)
    newfile_name=topic_name + ".txt"
    doc= open(newfile_name, "w")
    while True:
        cline=inFile.readline()
        if cline.startswith("</doc>"):
            break
        else:
            #print(cline)
            doc.write(cline)
            
    print("breaking")
    doc.close()
    #print("new line is "+ inFile.readline())
    inFile.close()
