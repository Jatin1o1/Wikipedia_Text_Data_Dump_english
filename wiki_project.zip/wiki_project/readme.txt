

apdril data new folder contains the new processed files

the python script in adpril is the newest version with code commented

all the dat are contained in the folders data and adpril new data


all the data has been processed 